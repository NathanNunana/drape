from django.apps import AppConfig


class DrapeAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'drape_app'
